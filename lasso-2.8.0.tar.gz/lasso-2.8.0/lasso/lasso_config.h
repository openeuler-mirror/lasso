/* lasso/lasso_config.h.  Generated from lasso_config.h.in by configure.  */
/* lasso/lasso_config.h.in. */

#define LASSO_LOG_DOMAIN "Lasso"
