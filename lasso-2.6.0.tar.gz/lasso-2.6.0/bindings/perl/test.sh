#!/bin/bash
LD_LIBRARY_PATH=../../lasso/.libs make -f Makefile.perl test
