#!/usr/bin/perl

use ExtUtils::testlib;

use Lasso
