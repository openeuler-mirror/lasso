/* lasso/lasso_config.h.  Generated from lasso_config.h.in by configure.  */
/* lasso/lasso_config.h.in. */

/* Define if ID-WSF support is enabled */
/* #undef LASSO_WSF_ENABLED */
#define LASSO_LOG_DOMAIN "Lasso"
